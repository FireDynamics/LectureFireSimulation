for i in *; do 
    echo "Found file: " $i
done