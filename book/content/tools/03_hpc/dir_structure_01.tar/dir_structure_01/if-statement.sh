echo "Checking for file:" $1

if [ -e $1 ]; then
    echo "File exists" 
else
    echo "File does not exists" 
fi