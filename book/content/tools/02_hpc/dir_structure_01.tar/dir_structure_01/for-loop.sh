for i in *; do 
    echo "Found directory element: " $i
done